/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frogger;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class Frogger extends Application {
    
    final static Image backgroundImg = new Image("https://codingwednesday.weebly.com/uploads/3/7/5/4/37546767/frogger_background.gif");
    final static Image carImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/car_b_0.png?raw=true");
    final static Image racecar2Img = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/car_a_0.png?raw=true");
    final static Image truckImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/car_c_0.png?raw=true");
    final static Image bulldozerImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/car_d_0.png?raw=true");
    final static Image racecarImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/car_e_0.png?raw=true");
    final static Image frogImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/frog_up_0.png?raw=true");
    final static Image logImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/log_0.png?raw=true");
    final static Image turtleImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/turtle_1.png?raw=true");
    final static Image frogSafeImg = new Image("https://github.com/leonardo-ono/Java2DFroggerGame/blob/master/src/res/win_0.png?raw=true");
    
    static Canvas canvas = new Canvas(520,550);
    static GraphicsContext context = canvas.getGraphicsContext2D(); 
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root, 520, 550);
    Timer timer = new Timer();
    static Timer startTimer = new Timer();
    static Random rand = new Random();
    
    static ArrayList<Vehicle> vehicles = new ArrayList<>();
    static ArrayList<Log> logs = new ArrayList<>();
    static Frog frog;
    static int i,logIndex=0;
    static String direction="";
    static boolean moveWithLog=false,start=false;
    static boolean spot1Full=false,spot2Full=false,spot3Full=false,spot4Full=false,spot5Full=false;
    
    public static class Frog{
        
        int x;
        int y;
        boolean killed;
        boolean safe;
        
        public Frog(int x,int y){
            this.x=x;
            this.y=y;
            this.killed=false;
            this.safe=false;
        }
    }
    
    public static class Vehicle{
        
        int x;
        int y;
        int width;
        int height;
        int velocityX;
        String type;
        
        public Vehicle(int x,int y,int width, int height,int velocityX, String type){
            this.x=x;
            this.y=y;
            this.width=width;
            this.height=height;
            this.velocityX=velocityX;
            this.type=type;
        }
    }
    
    public static class Log{
        
        int x;
        int y;
        int width;
        int height;
        int velocityX;
        
        public Log(int x,int y,int width, int height,int velocityX){
            this.x=x;
            this.y=y;
            this.width=width;
            this.height=height;
            this.velocityX=velocityX;;
        }
    }
    
    public static void generateRaceCar(){
        vehicles.add(new Vehicle(-30,355,30,30,10,"racecar"));
    }
    public static void generateRaceCar2(){
        vehicles.add(new Vehicle(-30,475,30,30,5,"racecar2"));
    }
    public static void generateTruck(){
        vehicles.add(new Vehicle(520,315,90,30,-3,"truck"));
    }
    public static void generateCar(){
        vehicles.add(new Vehicle(520,395,30,30,-5,"car"));
    }
    public static void generateBulldozer(){
        vehicles.add(new Vehicle(-30,435,30,30,4,"bulldozer"));
    }
    
    public static void generateLogOnRow5(){
        logs.add(new Log(520,235,90,30,-5));
    }
    
    public static void generateLogOnRow4(){
        logs.add(new Log(-45,195,45,30,5));
    }
    
     public static void generateLogOnRow2(){
        logs.add(new Log(-45,115,45,30,5));
    }
    
     public static void generateLogOnRow3(){
        logs.add(new Log(520,155,90,30,-5));
    }
    
     public static void generateLogOnRow1(){
        logs.add(new Log(520,75,90,30,-5));
    }
    
     public static void deleteObjects(){
         
         for(i=0;i<=vehicles.size()-1;i++){
             
             if(vehicles.get(i).x+vehicles.get(i).width<0 || vehicles.get(i).x>520){
                 vehicles.remove(vehicles.get(i));
             }
         }
         
          for(i=0;i<=logs.size()-1;i++){
             
             if(logs.get(i).x+logs.get(i).width<0 || logs.get(i).x>520){
                 logs.remove(logs.get(i));
             }
         }
          
     }
    public static void updateScreen(){
        
        // clear screen 
        context.clearRect(0,0,520,550);
        
        // draw background image 
        context.drawImage(backgroundImg,0,0,520,550);
       
        // move frog 
        if(direction=="left"){
            frog.x-=40;
        }
        if(direction=="right"){
            frog.x+=40;
        }
        if(direction=="up"){
            frog.y-=40;
        }
        if(direction=="down"){
            frog.y+=40;
        }
        direction="";
        
        // frog dies if it moves off the screen 
        if( 75<=frog.y && frog.y+30<=265 && (frog.x+30<0 || frog.x>520)){
            frog.killed=true;
        }
        
        if( 275<=frog.y && frog.y+30<=545 && (frog.x+30<0 || frog.x>520)){
            frog.killed=true;
        }

        // draw vehicles 
        for(i=0;i<=vehicles.size()-1;i++){
            
            if(vehicles.get(i).type=="truck"){
                context.drawImage(truckImg,vehicles.get(i).x,vehicles.get(i).y,vehicles.get(i).width,vehicles.get(i).height);
            }
            
            else if(vehicles.get(i).type=="racecar"){
                context.drawImage(racecarImg,vehicles.get(i).x,vehicles.get(i).y,vehicles.get(i).width,vehicles.get(i).height);
            }
            
            else if(vehicles.get(i).type=="car" ){
                context.drawImage(carImg,vehicles.get(i).x,vehicles.get(i).y,vehicles.get(i).width,vehicles.get(i).height);
            }
            
            else if(vehicles.get(i).type=="bulldozer" ){
                context.drawImage(bulldozerImg,vehicles.get(i).x,vehicles.get(i).y,vehicles.get(i).width,vehicles.get(i).height);
            }
            
            else if(vehicles.get(i).type=="racecar2" ){
                context.drawImage(racecar2Img,vehicles.get(i).x,vehicles.get(i).y,vehicles.get(i).width,vehicles.get(i).height);
            }
            
            // vehicle hits frog 
            if(((frog.x>=vehicles.get(i).x && frog.x<=vehicles.get(i).x+vehicles.get(i).width) || (frog.x+30>=vehicles.get(i).x && frog.x+30<=vehicles.get(i).x+vehicles.get(i).width))  && frog.y==vehicles.get(i).y){
                frog.killed=true;
            }
          
            vehicles.get(i).x+=vehicles.get(i).velocityX;
            
        }
        
        // draw logs 
        for(i=0;i<=logs.size()-1;i++){
            
            
           context.drawImage(logImg,logs.get(i).x,logs.get(i).y,logs.get(i).width,logs.get(i).height);

            // check if frog is on log 
            if(frog.x+15 <logs.get(i).x+logs.get(i).width && logs.get(i).x<frog.x+15 && frog.y ==logs.get(i).y){
                moveWithLog=true;
                logIndex=i;
            }
            
            
            logs.get(i).x+=logs.get(i).velocityX;
            
            if(moveWithLog && 75<=frog.y && frog.y+30<=265 && logIndex==i){
                frog.x+=logs.get(i).velocityX;;
            }
        }
        
        // draw frog lily pads 
        if(spot1Full){
            context.drawImage(frogSafeImg,15,20,50,50);
        }
        if(spot2Full){
            context.drawImage(frogSafeImg,125,20,50,50);
        }
        if(spot3Full){
            context.drawImage(frogSafeImg,235,20,50,50);
        }
        if(spot4Full){
            context.drawImage(frogSafeImg,345,20,50,50);
        }
        if(spot5Full){
            context.drawImage(frogSafeImg,455,20,50,50);
        }
        
        // frog moves to one of the safe lily pads 
        if(frog.y<75){
            
            // lily pad 1 
            if(frog.x+15<65 && frog.x+15>15 && frog.y+15<70 && frog.y+15>20 && !spot1Full){
                spot1Full=true;
                frog.safe=true;
            }
        
            // lily pad 2 
            else if(frog.x+15<175 && frog.x+15>125 && frog.y+15<70 && frog.y+15>20 && !spot2Full){
                spot2Full=true;
                frog.safe=true;
        }
        
            // lily pad 3
            else if(frog.x+15<285 && frog.x+15>235 && frog.y+15<70 && frog.y+15>20 && !spot3Full){
                spot3Full=true;
                frog.safe=true;
            }
        
            // lily pad 4
            else if(frog.x+15<395 && frog.x+15>345 && frog.y+15<70 && frog.y+15>20 && !spot4Full){
                spot4Full=true;
                 frog.safe=true;
            }
        
            // lily pad 5
            else if(frog.x+15<505 && frog.x+15>455 && frog.y+15<70 && frog.y+15>20 && !spot5Full){
                spot5Full=true;
                frog.safe=true;
            }
            
            else{
                frog.killed=true;
            }
        }
        
        // frog falls into river
        if(!moveWithLog && 75<=frog.y && frog.y+30<=265){
                frog.killed=true;
        }
            
        moveWithLog=false;
            
        // draw frog image 
        if(!frog.killed && !frog.safe){
            context.drawImage(frogImg,frog.x,frog.y,30,30);
        }
        
        else{
            if(frog.killed){
                frog = new Frog(285,515); 
            }
            else if(frog.safe){
                
                frog= new Frog(285,515);
                
                if(spot1Full && spot2Full && spot3Full && spot4Full && spot5Full){
                    
                    spot1Full=false;
                    spot2Full=false;
                    spot3Full=false;
                    spot4Full=false;
                    spot5Full=false;
                    
                    frog = new Frog(285,515); 
                    
                }
            }
        }
        
        deleteObjects();
    }
    
    @Override
    public void start(Stage primaryStage) {
        
        frog = new Frog(285,515); 
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                updateScreen();
            }
        },0,50);
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateTruck();
            }
        },0,3000);
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateRaceCar();
            }
        },0,2600);
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateCar();
            }
        },0,2000);
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateBulldozer();
            }
        },0,2500);
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateRaceCar2();
            }
        },0,2600);
        

        
        timer.scheduleAtFixedRate(new TimerTask() {
            
            @Override
            public void run() {
                generateLogOnRow1();
                generateLogOnRow3();
                generateLogOnRow5();
            }
        },0,2500);
        
 
        
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateLogOnRow2();
                generateLogOnRow4();
            }
        },0,1500);
        
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                start=true;
            }
        },0,8000);
        
         // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
           if(start){
                if (key.getCode() == KeyCode.A ) {
                    direction="left";
                }
            
                if (key.getCode() == KeyCode.D ) {
                    direction="right";
                }
            
                if (key.getCode() == KeyCode.W) {
                   direction="up";
                }
                if (key.getCode() == KeyCode.S ) {
                    direction="down";
                }
            }
        });
        
        primaryStage.setTitle("Frogger");
        primaryStage.setScene(scene);
        primaryStage.show();
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
